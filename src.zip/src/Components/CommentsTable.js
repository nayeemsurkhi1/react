import React from "react";

const CommentsTable = ({ comments, setComments, onEdit }) => {
  const onDelete = (index) => {
    setComments([...comments.filter((item, i) => i !== index)]);
  };

  return (
    <>
      <div className="records">
        <table className="table table-striped">
          <thead>
            <tr>
              <th scope="col">PostId</th>
              <th scope="col">Id</th>
              <th scope="col">Name</th>
              <th scope="col">Email</th>
              <th scope="col">Body</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {comments.map(({ postId, id, name, email, body }, index) => (
              <tr key={index}>
                <td key={postId}>{postId}</td>
                <td key={id}>{id}</td>
                <td key={name}>{name}</td>
                <td key={email}>{email}</td>
                <td key={body}>{body}</td>
                <td>
                  <input
                    type="button"
                    className="p-2 m-1 btn btn-warning"
                    onClick={() => onEdit(index)}
                    value="Update"
                  />

                  <input
                    type="button"
                    className="p-2 m-1 btn btn-danger"
                    onClick={() => onDelete(index)}
                    value="Delete"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default CommentsTable;
