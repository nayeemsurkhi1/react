import React from "react";
// import BookStore from "./Components/BookStore";
import Comments from "./Components/Comments";

function App() {
  return (
    <div>
      <Comments />
      {/* <BookStore /> */}
    </div>
  );
}

export default App;
